loadstring(game:HttpGet("https://raw.githubusercontent.com/hharu02/ssadsdasd/main/asdas"))()
DaHoodSettings.Prediction = 0.135
Aiming.TargetPart = {"Head", "LeftHand", "RightHand", "LeftLowerArm", "RightLowerArm", "LeftUpperArm", "RightUpperArm", "LeftFoot", "LeftLowerLeg", "UpperTorso", "HumanoidRootPart", "LeftUpperLeg", "RightLowerLeg", "RightFoot", "LowerTorso"}
Aiming.FOV = 17.4
Aiming.FOVSides = 25
Aiming.HitChance = 110
Aiming.ShowFOV = false